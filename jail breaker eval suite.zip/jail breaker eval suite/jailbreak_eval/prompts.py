"""Loading and filtering the adversarial prompt bank."""

from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from .models import Prompt


def load_prompts(path: str, category: Optional[str] = None, limit: Optional[int] = None) -> List[Prompt]:
    """Load prompts from a JSON file, optionally filtered by category and truncated to limit."""
    raw = Path(path).read_text()
    data = json.loads(raw)
    if not isinstance(data, list):
        raise ValueError(f"{path} must contain a JSON array of prompt objects.")

    prompts = [Prompt.from_dict(item) for item in data]

    if category:
        known = {p.category for p in prompts}
        if category not in known:
            raise ValueError(f"Unknown category '{category}'. Available categories: {sorted(known)}")
        prompts = [p for p in prompts if p.category == category]

    if limit is not None:
        prompts = prompts[:limit]

    return prompts
