"""Jailbreak Eval Suite — a minimal red-team harness for adversarial prompt testing."""

__version__ = "1.0.0"
