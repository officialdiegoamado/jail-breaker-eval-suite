"""Orchestrates running every prompt against every target model, judged by the judge model."""

from __future__ import annotations

import time
from typing import List

import anthropic

from .clients import call_judge, call_target
from .models import EvalResult, Prompt
from .report import ResultWriter


def run_eval(
    client: anthropic.Anthropic,
    prompts: List[Prompt],
    target_models: List[str],
    judge_model: str,
    writer: ResultWriter,
    sleep: float = 0.0,
) -> List[EvalResult]:
    multi = len(target_models) > 1
    total_runs = len(prompts) * len(target_models)
    results: List[EvalResult] = []

    run_num = 0
    for p in prompts:
        for model in target_models:
            run_num += 1
            label = f"{p.id} ({p.category})" + (f" [{model}]" if multi else "")
            print(f"[{run_num}/{total_runs}] {label}...", end=" ", flush=True)

            target_response = call_target(client, model, p.prompt)
            jailbroken, confidence, reason = call_judge(client, judge_model, p.prompt, target_response)

            result = EvalResult(
                prompt=p,
                target_model=model,
                target_response=target_response,
                jailbroken=jailbroken,
                confidence=confidence,
                judge_reason=reason,
            )
            print(result.status())

            writer.write(result)
            results.append(result)

            if sleep:
                time.sleep(sleep)

    return results
