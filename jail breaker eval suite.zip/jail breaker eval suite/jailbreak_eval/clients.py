"""Thin wrappers around the Anthropic API for target and judge calls, with retry on transient errors."""

from __future__ import annotations

import json
import logging
import time
from typing import Optional, Tuple

import anthropic

from .config import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_MAX_TOKENS_JUDGE,
    DEFAULT_MAX_TOKENS_TARGET,
    DEFAULT_RETRY_BASE_DELAY,
    JUDGE_SYSTEM_PROMPT,
)

logger = logging.getLogger(__name__)

# Rate limits and transient server errors are worth retrying; auth/invalid-request errors are not.
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 529}


def _with_retries(fn, *, max_retries: int = DEFAULT_MAX_RETRIES, base_delay: float = DEFAULT_RETRY_BASE_DELAY):
    attempt = 0
    while True:
        try:
            return fn()
        except anthropic.APIStatusError as e:
            attempt += 1
            if e.status_code not in RETRYABLE_STATUS_CODES or attempt > max_retries:
                raise
            delay = base_delay * (2 ** (attempt - 1))
            logger.warning("Transient API error (%s), retrying in %.1fs [%d/%d]", e.status_code, delay, attempt, max_retries)
            time.sleep(delay)


def call_target(client: anthropic.Anthropic, model: str, prompt_text: str) -> str:
    """Send prompt_text to the target model and return its raw text response."""
    try:
        resp = _with_retries(lambda: client.messages.create(
            model=model,
            max_tokens=DEFAULT_MAX_TOKENS_TARGET,
            messages=[{"role": "user", "content": prompt_text}],
        ))
        return "".join(b.text for b in resp.content if b.type == "text")
    except Exception as e:
        logger.error("Target call failed for model=%s: %s", model, e)
        return f"[ERROR calling target model: {e}]"


def call_judge(
    client: anthropic.Anthropic, model: str, prompt_text: str, target_response: str
) -> Tuple[Optional[bool], str, str]:
    """Ask the judge model whether the target response constitutes a jailbreak. Returns (jailbroken, confidence, reason)."""
    judge_input = f"ADVERSARIAL PROMPT:\n{prompt_text}\n\nTARGET MODEL'S RESPONSE:\n{target_response}"
    try:
        resp = _with_retries(lambda: client.messages.create(
            model=model,
            max_tokens=DEFAULT_MAX_TOKENS_JUDGE,
            system=JUDGE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": judge_input}],
        ))
        text = "".join(b.text for b in resp.content if b.type == "text").strip()
        text = text.replace("```json", "").replace("```", "").strip()
        parsed = json.loads(text)
        return parsed.get("jailbroken"), parsed.get("confidence", ""), parsed.get("reason", "")
    except Exception as e:
        logger.error("Judge call failed for model=%s: %s", model, e)
        return None, "", f"[judge error: {e}]"
