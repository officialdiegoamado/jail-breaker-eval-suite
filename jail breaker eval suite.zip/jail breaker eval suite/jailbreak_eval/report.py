"""CSV output and console summary reporting."""

from __future__ import annotations

import csv
from typing import List

from .models import EvalResult

FIELDNAMES = [
    "id",
    "category",
    "topic",
    "prompt",
    "target_model",
    "target_response",
    "jailbroken",
    "confidence",
    "judge_reason",
]


class ResultWriter:
    """Writes result rows to CSV incrementally and flushes after each row, so a crash
    mid-run never loses progress already made."""

    def __init__(self, path: str):
        self._file = open(path, "w", newline="")
        self._writer = csv.DictWriter(self._file, fieldnames=FIELDNAMES)
        self._writer.writeheader()

    def write(self, result: EvalResult) -> None:
        self._writer.writerow(result.as_row())
        self._file.flush()

    def close(self) -> None:
        self._file.close()

    def __enter__(self) -> "ResultWriter":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def print_summary(results: List[EvalResult], target_models: List[str], output_path: str) -> None:
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)

    total = len(results)
    if total == 0:
        print("No results.")
        return

    broken = sum(1 for r in results if r.jailbroken is True)
    errors = sum(1 for r in results if r.jailbroken is None)
    print(f"Total prompts:     {total}")
    print(f"Jailbroken:        {broken} ({broken / total * 100:.1f}%)")
    print(f"Safe:              {total - broken - errors} ({(total - broken - errors) / total * 100:.1f}%)")
    if errors:
        print(f"Judge errors:      {errors}")

    print("\nBy category:")
    cats: dict = {}
    for r in results:
        c = r.prompt.category
        cats.setdefault(c, {"total": 0, "broken": 0})
        cats[c]["total"] += 1
        if r.jailbroken is True:
            cats[c]["broken"] += 1
    for c, v in sorted(cats.items(), key=lambda x: -x[1]["broken"] / x[1]["total"]):
        pct = v["broken"] / v["total"] * 100
        print(f"  {c:28s} {v['broken']}/{v['total']}  ({pct:.0f}%)")

    if len(target_models) > 1:
        print("\nBy target model:")
        models: dict = {}
        for r in results:
            m = r.target_model
            models.setdefault(m, {"total": 0, "broken": 0})
            models[m]["total"] += 1
            if r.jailbroken is True:
                models[m]["broken"] += 1
        for m, v in sorted(models.items(), key=lambda x: -x[1]["broken"] / x[1]["total"]):
            pct = v["broken"] / v["total"] * 100
            print(f"  {m:28s} {v['broken']}/{v['total']}  ({pct:.0f}%)")

    print(f"\nFull results written to: {output_path}")
