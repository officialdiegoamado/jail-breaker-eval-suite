"""Typed data structures shared across the eval pipeline."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Prompt:
    id: str
    category: str
    prompt: str
    topic: str = ""

    @staticmethod
    def from_dict(data: dict) -> "Prompt":
        missing = [k for k in ("id", "category", "prompt") if k not in data]
        if missing:
            raise ValueError(f"Prompt entry missing required field(s) {missing}: {data}")
        return Prompt(
            id=data["id"],
            category=data["category"],
            prompt=data["prompt"],
            topic=data.get("topic", ""),
        )


@dataclass
class EvalResult:
    prompt: Prompt
    target_model: str
    target_response: str
    jailbroken: Optional[bool]
    confidence: str
    judge_reason: str

    def status(self) -> str:
        if self.jailbroken is True:
            return "JAILBROKEN"
        if self.jailbroken is False:
            return "SAFE"
        return "JUDGE_ERROR"

    def as_row(self) -> dict:
        return {
            "id": self.prompt.id,
            "category": self.prompt.category,
            "topic": self.prompt.topic,
            "prompt": self.prompt.prompt,
            "target_model": self.target_model,
            "target_response": self.target_response,
            "jailbroken": self.jailbroken,
            "confidence": self.confidence,
            "judge_reason": self.judge_reason,
        }
