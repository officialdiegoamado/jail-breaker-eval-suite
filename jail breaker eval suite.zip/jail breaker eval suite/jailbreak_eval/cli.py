"""Command-line entrypoint for the jailbreak eval suite."""

from __future__ import annotations

import argparse
import logging
import os
from datetime import datetime

import anthropic

from .config import (
    DEFAULT_JUDGE_MODEL,
    DEFAULT_OUTPUT_PATH,
    DEFAULT_PROMPTS_PATH,
    DEFAULT_TARGET_MODEL,
    get_api_key,
)
from .prompts import load_prompts
from .report import ResultWriter, print_summary
from .runner import run_eval


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Jailbreak eval suite — test whether a model can be jailbroken by known adversarial prompts."
    )
    parser.add_argument("--prompts", default=DEFAULT_PROMPTS_PATH, help="Path to prompts JSON file")
    parser.add_argument(
        "--target-model",
        default=os.environ.get("TARGET_MODEL", DEFAULT_TARGET_MODEL),
        help="Comma-separated list of target models to test, e.g. claude-opus-5,claude-sonnet-5,claude-haiku-4-5-20251001",
    )
    parser.add_argument("--judge-model", default=os.environ.get("JUDGE_MODEL", DEFAULT_JUDGE_MODEL))
    parser.add_argument("--category", default=None, help="Only run prompts from this category")
    parser.add_argument("--limit", type=int, default=None, help="Only run the first N prompts")
    parser.add_argument("--output", default=DEFAULT_OUTPUT_PATH)
    parser.add_argument("--sleep", type=float, default=0.0, help="Seconds to sleep between calls (rate limiting)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging (retries, API errors)")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
    )

    try:
        api_key = get_api_key()
    except RuntimeError as e:
        print(f"ERROR: {e}")
        return 1

    client = anthropic.Anthropic(api_key=api_key)

    try:
        prompts = load_prompts(args.prompts, category=args.category, limit=args.limit)
    except FileNotFoundError:
        print(f"ERROR: prompts file not found: {args.prompts}")
        return 1
    except ValueError as e:
        print(f"ERROR: {e}")
        return 1

    if not prompts:
        print("No prompts matched your filters.")
        return 0

    target_models = [m.strip() for m in args.target_model.split(",") if m.strip()]

    print(
        f"Running {len(prompts)} prompts x {len(target_models)} target model(s) "
        f"({len(prompts) * len(target_models)} total) | "
        f"target={','.join(target_models)} | judge={args.judge_model}\n"
    )

    with ResultWriter(args.output) as writer:
        try:
            results = run_eval(client, prompts, target_models, args.judge_model, writer, sleep=args.sleep)
        except KeyboardInterrupt:
            print("\nInterrupted — partial results were saved to", args.output)
            return 130

    print_summary(results, target_models, args.output)
    print(f"Run finished at {datetime.now().isoformat(timespec='seconds')}")
    return 0
