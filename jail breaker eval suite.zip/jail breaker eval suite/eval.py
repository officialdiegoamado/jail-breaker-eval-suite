#!/usr/bin/env python3
"""
Jailbreak Eval Suite — CLI entrypoint.

The implementation lives in the jailbreak_eval/ package; this file exists so
`python eval.py ...` keeps working exactly as before.

Setup:
  pip install -r requirements.txt
  export ANTHROPIC_API_KEY=sk-ant-...

Usage:
  python eval.py                        # run everything
  python eval.py --limit 5              # quick smoke test on first 5 prompts
  python eval.py --category roleplay_persona   # only run one category
  python eval.py --target-model claude-sonnet-5 --judge-model claude-sonnet-5

  # multi-target: run every prompt against each model, same judge
  python eval.py --target-model claude-opus-5,claude-sonnet-5,claude-haiku-4-5-20251001
"""

import sys

try:
    from jailbreak_eval.cli import main
except ImportError:
    print("Missing dependency. Run: pip install -r requirements.txt --break-system-packages")
    sys.exit(1)

if __name__ == "__main__":
    sys.exit(main())
